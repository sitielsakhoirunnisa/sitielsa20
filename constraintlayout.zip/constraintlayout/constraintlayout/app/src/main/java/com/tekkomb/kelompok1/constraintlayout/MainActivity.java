package com.tekkomb.kelompok1.constraintlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {

    //membuat variable untuk memanggil widget

    EditText username;
    EditText password;
    Button button_klik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //mengisi variabel yang sudah dibuat dan diisi oleh id xml

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        button_klik = (Button) findViewById(R.id.btnlogin);
        button_klik.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String user_name = username.getText().toString();
        String pass_ = password.getText().toString();
        if (user_name.equals("admin") && pass_.equals("123")) {
            Toast.makeText(getApplicationContext(), "Username dan Password benar Anda berhasil Login", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "Username dan Pssword tidak sesuai Anda gagal Login", Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent(MainActivity.this, halamandua.class);
        startActivity(intent);
    }

}
